import pandas as pd

# Grouping Data in Pandas
print("Grouping Data:")

data = {'Department': ['HR', 'IT', 'HR', 'IT', 'Finance', 'Finance', 'HR'],
        'Employee': ['Alice', 'Bob', 'Charlie', 'David', 'Eve', 'Frank', 'Grace'],
        'Salary': [50000, 60000, 55000, 65000, 70000, 72000, 58000]}

df = pd.DataFrame(data)
print("Original DataFrame:")
print(df)

# Grouping by Department and calculating mean salary
print("\nMean Salary by Department:")
grouped_df = df.groupby('Department')['Salary'].mean()
print(grouped_df)

# Grouping by Department and counting employees
print("\nEmployee count by Department:")
employee_count = df.groupby('Department')['Employee'].count()
print(employee_count)

# Grouping by Department and getting the sum of salaries
print("\nTotal Salary by Department:")
total_salary = df.groupby('Department')['Salary'].sum()
print(total_salary)