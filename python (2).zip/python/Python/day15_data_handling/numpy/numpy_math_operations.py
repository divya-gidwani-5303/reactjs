import numpy as np

arr1 = np.array([1, 2, 3, 4])
arr2 = np.array([10, 20, 30, 40])
print(arr1 + arr2)  # Addition
print(arr1 - arr2)  # Subtraction
print(arr1 * arr2)  # Multiplication
print(arr1 / arr2)  # Division
print(arr1 ** 2)    # Square each element

arr = np.array([10, 20, 30, 40, 50])
print(np.mean(arr))   # Mean (average)
print(np.median(arr)) # Median
print(np.std(arr))    # Standard deviation
print(np.var(arr))    # Variance
print(np.sum(arr))    # Sum of all elements
print(np.min(arr))    # Minimum value
print(np.max(arr))    # Maximum value
