import numpy as np

# NumPy Array Copy vs View
arr21= np.array([1, 2, 3, 4, 5])
x = arr21.copy()
arr21[0] = 42
print(arr21)
print(x)
arr22 = np.array([1, 2, 3, 4, 5])
y = arr22.view()
arr22[0] = 42
print(arr22)
print(y)
print(x.base)
print(y.base)
