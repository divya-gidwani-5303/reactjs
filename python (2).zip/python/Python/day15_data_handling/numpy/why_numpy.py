# NumPy is much faster than lists for large datasets due to optimized C-based implementation.
import time
import numpy as np

# normal list-
list1 = [i for i in range(1000000)]
list2 = [i for i in range(1000000)]
start = time.time()
result = [x + y for x, y in zip(list1, list2)]
end = time.time()
print("Time taken using Python list:", end - start, "seconds")

# NumPy array-
arr1 = np.arange(1000000)
arr2 = np.arange(1000000)
start = time.time()
result = arr1 + arr2  # Vectorized operation
end = time.time()
print("Time taken using NumPy array:", end - start, "seconds")