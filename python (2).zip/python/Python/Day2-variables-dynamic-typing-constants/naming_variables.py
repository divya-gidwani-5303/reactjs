"""
must start with a letter or the underscore character
cannot start with a number
can only contain alpha-numeric characters and underscores (A-z, 0-9, and _ )
are case-sensitive (age, Age and AGE are three different variables)
cannot be any of the Python keywords.

"""