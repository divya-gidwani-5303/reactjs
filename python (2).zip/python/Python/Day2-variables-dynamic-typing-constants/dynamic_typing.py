"""
In Dynamic Typing, type checking is performed at runtime. 
For example, Python is a dynamically typed language. 
It means that the type of a variable is allowed to change over its lifetime
"""

## variable a is assigned to a string 
a ="hello"
print(type(a)) 
  
## variable a is assigned to an integer 
a = 5
print(type(a)) 