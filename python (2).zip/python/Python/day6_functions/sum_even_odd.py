# Function to sum even and odd numbers separately
def sum_even_odd(*nums):
    """Returns the sum of even and odd numbers separately as a tuple (even_sum, odd_sum)."""
    if not nums:
        return 0, 0
    
    even_sum = odd_sum = 0
    for num in nums:
        if num % 2 == 0:
            even_sum += num
        else:
            odd_sum += num
    return even_sum, odd_sum
