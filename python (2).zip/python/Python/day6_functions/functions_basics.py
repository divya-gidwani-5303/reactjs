# 1. Defining and Calling a Function
def greet():
    # This function prints a greeting message
    print("Hello, welcome to Python!")

greet()  # Calling the function

# 2. Function with Arguments
def greet_user(name):
    # This function takes a name as an argument and prints a greeting message
    print(f"Hello, {name}! Welcome to Python.")

greet_user("Alice")
greet_user("Bob")

# 3. Function with a Return Value
def add_numbers(a, b):
    # This function takes two numbers, adds them, and returns the sum
    return a + b

result = add_numbers(5, 3)  # Calling function and storing result
print("Sum:", result)

# 4. Default Arguments
def greet_again(name="Guest"):
    # If no argument is provided, the default value "Guest" is used
    print(f"Hello, {name}!")

greet_again()  # Uses default value

greet_again("Alice")  # Overrides default value
