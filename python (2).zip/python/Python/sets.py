# Exercise 1: Add a list of elements to a set
sample_set = {"Yellow", "Orange", "Black"}
sample_list = ["Blue", "Green", "Red"]
# {'Green', 'Yellow', 'Black', 'Orange', 'Red', 'Blue'}
for i in range(len(sample_list)):
    sample_set.add(sample_list[i])
print(sample_set)

# Exercise 2: Return a new set of identical items from two sets
set1 = {10, 20, 30, 40, 50}
set2 = {30, 40, 50, 60, 70}
# {40, 50, 30}
print(set1.intersection(set2))

# Exercise 3: Get Only unique items from two sets
set1 = {10, 20, 30, 40, 50}
set2 = {30, 40, 50, 60, 70}
print(set1.union(set2))

# Exercise 4: Update the first set with items that don’t exist in the second set
set1 = {10, 20, 30}
set2 = {20, 40, 50}
for item in set2:
    if(item in set1):
        set1.remove(item)
print(set1)

# Exercise 5: Remove items from the set at once
# Write a Python program to remove items 10, 20, 30 from the following set at once.
set1 = {10, 20, 30, 40, 50}
# {40, 50}
items_to_remove = {10, 20, 30}
set1.difference_update(items_to_remove)
print(set1)

# Exercise 6: Return a set of elements present in Set A or B, but not both
set1 = {10, 20, 30, 40, 50}
set2 = {30, 40, 50, 60, 70}
# {20, 70, 10, 60}
print("eehueh")
print(set1.symmetric_difference(set2))

# Exercise 7: Check if two sets have any elements in common. If yes, display the common elements
set1 = {10, 20, 30, 40, 50}
set2 = {60, 70, 80, 90, 10}
print(set1.intersection(set2))
# Exercise 8: Update set1 by adding items from set2, except common items
set1 = {10, 20, 30, 40, 50}
set2 = {30, 40, 50, 60, 70}
# {70, 10, 20, 60}
for items in set2:
    if(item in set1):
        set1.remove(item)
    else:
        set1.add(item)
print(set1)
# Exercise 9: Remove items from set1 that are not common to both set1 and set2
set1 = {10, 20, 30, 40, 50}
set2 = {30, 40, 50, 60, 70}
# {30, 40, 50}
items_to_keep = set1.difference(set2)
items_to_remove = set1.intersection(set2)
for items in items_to_remove:
    set1.remove(items)
print(set1)