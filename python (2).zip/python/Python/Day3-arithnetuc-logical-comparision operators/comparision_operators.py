# Comparison Operators Example

a = 10
b = 20

print(a == b)  # False
print(a != b)  # True
print(a > b)   # False
print(a < b)   # True
print(a >= b)  # False
print(a <= b)  # True

# Ek simple program jo user se number input lega aur check karega ki number positive hai ya nahi

num = int(input("Enter a number: "))

if num > 0:
    print("Positive Number")
elif num == 0:
    print("Zero")
else:
    print("Negative Number")

print("apple" == "apple")   # True 
print("apple" != "orange")  # True 
print("banana" > "apple")   # True 
print("apple" < "banana")   # True 

print(10 == "10")  # False
print(10 != "10")  # True


# ex-3
correct_username = "admin"
correct_password = "1234"
# solu
username = input("Enter username: ")
password = input("Enter password: ")
if (username == correct_username) and (password == correct_password):
    print("Granted!")
else:
    print("Access Denied!")