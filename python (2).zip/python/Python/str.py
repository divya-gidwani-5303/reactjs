# # Exercise 1A: Create a string made of the first, middle and last character
# str1 = "James"
# # Jms
# print(str1[0]+str1[int(len(str1)/2)]+str1[int(len(str1)-1)])

# # Exercise 1B: Create a string made of the middle three characters
# str1 = "JhonDipPeta"
# # Output-Dip
# str2 = "JaSonAy"
# # Output-Son
# midstr1=int((len(str1)-1)/2)
# str1_1=str1[midstr1-1]+str1[midstr1]+str1[midstr1+1]
# print(str1_1)

# midstr2=int((len(str2)-1)/2)
# str2_1=str2[midstr2-1]+str2[midstr2]+str2[midstr2+1]
# print(str2_1)

# # Exercise 2: Append new string in the middle of a given string
# # Given two strings, s1 and s2. Write a program to create a new string s3 by appending s2 in the middle of s1.
# s1 = "Ault"
# s2 = "Kelly"
# s3=""
# # Expected Output:AuKellylt
# mids1=int((len(s1)/2)-1)
# for i in range(len(s1)):
#     s3+=s1[i]
#     if(i==mids1):
#         for j in range(len(s2)):
#             s3+=s2[j]
# print(s3)
# # Exercise 3: Create a new string made of the first, middle, and last characters of each input string
# # Given two strings, s1 and s2, write a program to return a new string made of s1 and s2’s first, middle, and last characters.
# s1 = "America"
# s2 = "Japan"
# # AJrpan
# mids1= int((len(s1)-1)/2)
# mids2= int((len(s2)-1)/2)

# # Exercise 4: Arrange string characters such that lowercase letters should come first
# str1 = "PyNaTive"
# # yaivePNT

# # Exercise 5: Count all letters, digits, and special symbols from a given string
# str1 = "P@#yn26at^&i5ve"
# # Total counts of chars, digits, and symbols 
# # Chars = 8 
# # Digits = 3 
# # Symbol = 4
# Chars = []
# Digits = [] 
# Symbol = []




# # Exercise 6: Create a mixed String using the following rules
# s1 = "Abc"
# s2 = "Xyz"
# # AzbycX
# def mix(s1,s2):
#     mix= s1[0]+s2[int(len(s2)-1)]+s1[int((len(s1)-1)/2)]+s2[int((len(s2)-1)/2)]+s1[int(len(s1)-1)]+s2[0]
#     print(mix)
# mix(s1,s2)

# # Exercise 7: String characters balance Test
# # Write a program to check if two strings are balanced. For example, strings s1 and s2 are balanced if all the characters in the s1 are present in s2. The character’s position doesn’t matter.
# # s1 = "Yn"
# # s2 = "PYnative"
# # Expected Output:True
s1 = "Yn"
s2 = "PYnative"
# Expected Output:False
def check_str(s1, s2):
    for char in s1:
        if char not in s2:
            return False
    return True
        


print(check_str(s1,s2))

# # Exercise 8: Find all occurrences of a substring in a given string by ignoring the case
str1 = "Welcome to USA. usa awesome, isn't it?"
# # The USA count is: 2
def occurance(str1):
    count=0
    str1Up = str1.lower().split(" ")
    # print(str1Up)
    for words in str1Up:
        if "usa" in words:
            count+=1
            # print(words)
    return count


print(occurance(str1))
# # Exercise 9: Calculate the sum and average of the digits present in a string
# # Given a string s1, write a program to return the sum and average of the digits that appear in the string, ignoring all other characters.
# str1 = "PYnative29@#8496"
# # Sum is: 38 Average is  6.333333333333333

# # Exercise 10: Write a program to count occurrences of all characters within a string
# str1 = "Apple"
# # {'A': 1, 'p': 2, 'l': 1, 'e': 1}

# # Exercise 11: Reverse a given string
# str1 = "PYnative"
# # evitanYP
# print(str1[::-1])

# # Exercise 12: Find the last position of a given substring
# # Write a program to find the last position of a substring “Emma” in a given string.
# str1 = "Emma is a data scientist who knows Python. Emma works at google."
# # Last occurrence of Emma starts at index 43
# for i in range(len(str1)-1, 1, -1):
#     if(str1[i] + str1[i-1] + str1[i-2] + str1[i-3] == "ammE"):
#         print(i-3)
# print("heue")
# print(len(str1)-1-3-(str1[::-1].find("ammE")))
# # Exercise 13: Split a string on hyphens
# str1 = "Emma-is-a-data-scientist"
# # Displaying each substring
# # Emma
# # is
# # a
# # data
# # scientist
# str1_1=str1.replace("-","\n")
# print(str1_1)

# # Exercise 14: Remove empty strings from a list of strings
# str_list = ["Emma", "Jon", "", "Kelly", None, "Eric", ""]
# # Original list of sting
# # ['Emma', 'Jon', '', 'Kelly', None, 'Eric', '']
# # # After removing empty strings
# # ['Emma', 'Jon', 'Kelly', 'Eric']
# for strin in str_list:
#     if strin=="" or strin==None:
#         str_list.remove(strin)
# print(str_list)

# # Exercise 15: Remove special symbols / punctuation from a string
# str1 = "/*Jon is @developer & musician"
# # "Jon is developer musician"
# for lett in str1:
#     if not lett.isalpha() and not lett.isspace():
#         str1 = str1.replace(lett, "")
# print(str1)

# # Exercise 16: Removal all characters from a string except integers
# str1 = 'I am 25 years and 10 months old'
# # 2510
# for num in str1:
#     if(num.isalpha()):
#         str1= str1.replace(num,"")
# print(str1.strip())

# # Exercise 17: Find words with both alphabets and numbers
# str1 = "Emma25 is Data scientist50 and AI Expert"
# # Emma25
# # scientist50
# st2=str1.split()
# print(st2)
# for words in st2:
#     if any(letter.isalpha() for letter in words) and any(letter.isdigit() for letter in words):
#         print(words)

# # Exercise 18: Replace each special symbol with # in the following string
# str1 = '/*Jon is @developer & musician!!'
# # ##Jon is #developer # musician##
# for letters in str1:
#     if(letters.isalpha()==False and letters.isspace()==False):
#         str1=str1.replace(letters,"")
# print(str1)
