import re

"""
Flags & Advanced Features:

re.IGNORECASE (re.I) → Case-insensitive matching
re.MULTILINE (re.M)  → Multi-line matching
re.DOTALL (re.S)     → Allows . to match newlines
"""

# re.IGNORECASE (re.I) → Case-insensitive matching
s1 = "Python is Awesome!"
p1 = r"python"
match1 = re.findall(p1, s1, re.IGNORECASE)
print("Case-insensitive matching (re.I):", match1) 

# re.MULTILINE (re.M) → Multi-line matching
s2 = """First line
Second line
Third line"""
p2 = r"^Second"
match2 = re.findall(p2, s2, re.MULTILINE)
match22 = re.findall(p2, s2)
print("Multi-line matching (re.M):", match2)  # Output: ['Second']
print("line matching (re.M):", match22)  

# re.DOTALL (re.S) → Allows . to match newlines
s3 = "Hello\nWorld!"
p3 = r"Hello.*World"
match3 = re.findall(p3, s3, re.DOTALL)
print("Dot matches newlines (re.S):", match3)  

# Combining multiple flags (re.I | re.M)
s4 = """apple
Banana
cherry"""
p4 = r"banana"
match4 = re.findall(p4, s4, re.IGNORECASE | re.MULTILINE)
print("Case-insensitive & multi-line (re.I | re.M):", match4)  
