"""
A Regular Expression (Regex) is a sequence of characters that defines a search pattern 
in a text. It helps in matching, searching, and manipulating strings efficiently.
"""
# without
text = "My phone number is 9876543210"
digits = ""
for char in text:
    if char.isdigit():
        digits += char
print(digits)  # Output: 9876543210

# with regex
import re
text = "My phone number is 9876543210"
digits = re.search(r"\d+", text).group()
print(digits)  # Output: 9876543210
