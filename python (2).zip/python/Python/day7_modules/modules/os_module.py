import os
import random
print("Current Working Directory:", os.getcwd())  # Prints the current working directory
print("List of files in current directory:", os.listdir())  # Lists all files and directories in the current directory
print("Environment Variables:", os.environ)  # Prints the environment variables

# Creating a directory
os.makedirs("test_directory", exist_ok=True)  # Creates a directory named 'test_directory' if it does not exist
print("Created directory: test_directory")

# Checking if a file exists
file_name = "example.txt"
if os.path.exists(file_name):
    print(f"{file_name} exists.")  # Checks if 'example.txt' exists and prints a message if it does
else:
    print(f"{file_name} does not exist.")  # Prints a message if 'example.txt' does not exist

# Getting system information
print("OS Name:", os.name)  # Prints the name of the operating system
print("User Home Directory:", os.path.expanduser("~"))  # Prints the path to the user's home directory
print("System Path:", os.getenv("PATH"))  # Prints the system PATH environment variable

# Creating and removing files
temp_file = "temp_file.txt"
with open(temp_file, "w") as f:
    f.write("This is a temporary file.")  # Creates a temporary file and writes some text to it
print(f"Created file: {temp_file}")

if os.path.exists(temp_file):
    os.remove(temp_file)  # Deletes the temporary file if it exists
    print(f"Deleted file: {temp_file}")

# Renaming a file
old_name = "old_file.txt"
new_name = "new_file.txt"
with open(old_name, "w") as f:
    f.write("Rename me!")  # Creates a file named 'old_file.txt' and writes some text to it
os.rename(old_name, new_name)  # Renames 'old_file.txt' to 'new_file.txt'
print(f"Renamed {old_name} to {new_name}")

# Removing a directory
if os.path.exists("test_directory"):
    os.rmdir("test_directory")  # Removes the directory named 'test_directory' if it exists
    print("Removed directory: test_directory")


# 6. Seeding Random Generator
random.seed(42)  # Seeds the random number generator with a specific value
print("Seeded random integer:", random.randint(1, 100))  # Generates a random integer between 1 and 100 using the seeded generator
