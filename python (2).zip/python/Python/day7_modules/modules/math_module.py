import math

# Basic mathematical operations
print(f"Square root of 25: {math.sqrt(25)}")  # Output: 5.0
print(f"Factorial of 5: {math.factorial(5)}")  # Output: 120
print(f"Value of Pi: {math.pi}")  # Output: 3.141592653589793

# Trigonometric functions
angle = 60  # degrees
radians = math.radians(angle)  # Convert degrees to radians

print(f"Sine of {angle} degrees: {math.sin(radians)}")  # Output: 0.8660254037844386
print(f"Cosine of {angle} degrees: {math.cos(radians)}")  # Output: 0.5000000000000001
print(f"Tangent of {angle} degrees: {math.tan(radians)}")  # Output: 1.7320508075688767

# Inverse trigonometric functions (results in radians)
# Note: The output is in radians, use math.degrees() to convert to degrees
print(f"Arcsine of 0.5 (in radians): {math.asin(0.5)}") # Output: 0.5235987755982989
print(f"Arccosine of 0.5 (in radians): {math.acos(0.5)}") # Output: 1.0471975511965979
print(f"Arctangent of 1 (in radians): {math.atan(1)}")# Output: 0.7853981633974483

# Hyperbolic functions
print(f"Sinh(0): {math.sinh(0)}")  # Output: 0.0
print(f"Cosh(0): {math.cosh(0)}")  # Output: 1.0
print(f"Tanh(0): {math.tanh(0)}")  # Output: 0.0

# Convert radians to degrees
rad = math.pi / 4
print(f"{rad} radians in degrees: {math.degrees(rad)}") # Output: 45.0

# Convert degrees to radians
deg = 30
print(f"{deg} degrees in radians: {math.radians(deg)}") # Output: 0.5235987755982988

# Logarithmic functions
print(f"Natural logarithm of 10: {math.log(10)}")  # Default base e
print(f"Base-2 logarithm of 32: {math.log2(32)}")  # Output: 5.0
print(f"Base-10 logarithm of 1000: {math.log10(1000)}")  # Output: 3.0

# Exponential and power functions
print(f"e^2 (Exponential of 2): {math.exp(2)}")  
print(f"e^3 (Exponential of 3): {math.exp(3)}")  # Output: 20.085536923187668
print(f"2 raised to the power 3: {math.pow(2, 3)}")  # Output: 8.0
print(f"3 raised to the power 4 using ** operator: {3 ** 4}")  # Output: 81

# Rounding functions
print(f"Floor of 4.7: {math.floor(4.7)}")  # Rounds down to 4
print(f"Ceiling of 4.2: {math.ceil(4.2)}")  # Rounds up to 5
print(f"Rounding 4.6: {round(4.6)}")  # Output: 5
print(f"Rounding 4.4: {round(4.4)}")  # Output: 4

# Absolute value and modulus
print(f"Absolute value of -15: {math.fabs(-15)}")  # Output: 15.0
print(f"Modulus of -10.3: {math.fmod(-10.3, 3)}")  # Output: -1.3

# Greatest Common Divisor (GCD)
print(f"GCD of 48 and 18: {math.gcd(48, 18)}")  # Output: 6

# Least Common Multiple (LCM) - Python 3.9+
print(f"LCM of 12 and 18: {math.lcm(12, 18)}")  # Output: 36

# Hypotenuse calculation (Pythagoras theorem)
print(f"Hypotenuse of a right triangle with sides 3 and 4: {math.hypot(3, 4)}")  # Output: 5.0

# Hyperbolic functions
x = 2
print(f"Sinh({x}): {math.sinh(x)}")  
print(f"Cosh({x}): {math.cosh(x)}")  
print(f"Tanh({x}): {math.tanh(x)}")  

# Constants
print(f"Euler's number (e): {math.e}")  # Output: 2.718281828459045
print(f"Golden ratio (φ approximation): {1.61803398875}")  
print(f"Tau (τ = 2π): {math.tau}")  # Output: 6.283185307179586

# Using copysign (copy sign of one number to another)
print(f"Copying sign: {math.copysign(10, -5)}")  # Output: -10.0
print(f"Copying sign: {math.copysign(-10, 5)}")  # Output: 10.0
