# my_module.py

# Function to add two numbers
def add(a: int, b: int) -> int:
    """Returns the sum of two numbers."""
    return a + b


# Function to subtract the second number from the first
def subtract(a, b):
    """Returns the difference between two numbers."""
    return a - b

# Function to multiply two numbers
def multiply(a, b):
    """Returns the product of two numbers."""
    return a * b

# Function to divide the first number by the second
def divide(a, b):
    """Returns the division of two numbers. Handles division by zero."""
    if b == 0:
        return "Error: Division by zero is not allowed."
    return a / b

# A constant variable representing the value of Pi
PI = 3.14159

# This block prevents the code from running when imported
if __name__ == "__main__":
    print("This is my_module, a custom Python module.")