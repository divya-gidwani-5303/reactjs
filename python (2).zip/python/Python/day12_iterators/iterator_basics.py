"""
Python iterator protocol requires an object to have:
An __iter__() method that returns the iterator itself.
A __next__() method that returns the next item or raises StopIteration.
When you use next(obj), Python internally calls obj.__next__().
"""
# Difference between Iterable and Iterator
numbers = [1, 2, 3, 4]  # iterable
iterator_for_numbers = iter(numbers)  # Convert to an Iterator

print("Using next() on an Iterator:")
print(next(iterator_for_numbers))  # Output: 1
print(next(iterator_for_numbers))  # Output: 2



# Using iter() with Strings
text = "Python"
text_iter = iter(text)
print("\nUsing next() with a String Iterator:")
print(next(text_iter))  # Output: P
print(next(text_iter))  # Output: y


# Using iter() with Dictionaries
my_dict = {'a': 1, 'b': 2, 'c': 3}
dict_iter = iter(my_dict)
print("\nUsing next() with a Dictionary Iterator:")
print(next(dict_iter))  # Output: a
print(next(dict_iter))  # Output: b


# Using iter() with Sets
my_set = {10, 20, 30}
set_iter = iter(my_set)

print("\nUsing next() with a Set Iterator:")
print(next(set_iter))  # Output: 10 (order may vary)
print(next(set_iter))  # Output: 20 (order may vary)


# Using iter() with Tuples
my_tuple = (100, 200, 300)
tuple_iter = iter(my_tuple)

print("\nUsing next() with a Tuple Iterator:")
print(next(tuple_iter))  # Output: 100
print(next(tuple_iter))  # Output: 200


# Using iter() with Files
with open("example.txt", "w") as f:
    f.write("Line 1\nLine 2\nLine 3")

with open("example.txt", "r") as f:
    file_iter = iter(f)
    print("\nUsing next() with a File Iterator:")
    print(next(file_iter).strip())  # Output: Line 1
    print(next(file_iter).strip())  # Output: Line 2
