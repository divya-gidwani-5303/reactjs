# Resetting an Iterator (Not Possible Directly)
class Counter:
    def __init__(self, start, end):
        self.start = start
        self.end = end
        self.current = start

    def __iter__(self):
        return self  

    def __next__(self):
        if self.current > self.end:
            raise StopIteration  
        num = self.current
        self.current += 1
        return num  

counter = Counter(1, 3)
print(next(counter))  # 1
print(next(counter))  # 2
print(next(counter))  # 3

# Resetting (Need to Create a New Object)
counter = Counter(1, 3)
print(next(counter))  # 1 (New object starts fresh)

# Implementing a Restartable Iterator
class RestartableCounter:
    def __init__(self, start, end):
        self.start = start
        self.end = end

    def __iter__(self):
        return Counter(self.start, self.end)  # Return a fresh iterator

# Using the restartable iterator
restartable = RestartableCounter(1, 3)
it1 = iter(restartable)
print(next(it1))  # 1
print(next(it1))  # 2

it2 = iter(restartable)  # New iterator (restartable)
print(next(it2))  # 1 (Starts fresh)