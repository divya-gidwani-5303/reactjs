class FileIterator:
    """Iterator to read a file line by line"""
    def __init__(self, filename):
        self.filename = filename

    def __iter__(self):
        self.file = open(self.filename, "r")  # Open file
        return self  

    def __next__(self):
        line = self.file.readline()  # Read next line
        if not line:  
            self.file.close()  # Close file when done
            raise StopIteration  
        return line.strip()  # Return line without trailing newline

# Using the FileIterator
file_name = "sample.txt"  # Make sure this file exists
with open(file_name, "w") as f:  # Create a sample file
    f.write("Hello\nPython\nIterators\n")

# Iterating over the file
file_iter = FileIterator(file_name)
for line in file_iter:
    print(line)  # Output: Hello, Python, Iterators

# Alternative: Using iter() with a file object (Python's built-in iterator)
with open(file_name, "r") as f:
    for line in iter(f.readline, ""):  # Reads until an empty string is returned
        print(line.strip())