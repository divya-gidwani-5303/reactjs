# Custom Iterator Example
class MyNumbers:
    def __init__(self, limit):
        self.limit = limit  # Maximum number to iterate up to
        self.current = 1  # Start counting from 1

    def __iter__(self):
        return self  # Returning self as the iterator object

    def __next__(self):
        if self.current > self.limit:
            raise StopIteration  # Stop iteration when limit is reached
        num = self.current
        self.current += 1  # Increment current value
        return num  # Return the current number

# Using the iterator
print("MyNumbers Iterator Output:")
numbers = MyNumbers(3)
for num in numbers:
    print(num)  # Output: 1, 2, 3

# Manual iteration using next()
print("\nManual Iteration Output:")
it = iter(MyNumbers(3))
print(next(it))  # Output: 1
print(next(it))  # Output: 2
print(next(it))  # Output: 3
# print(next(it))  # Raises StopIteration (Uncomment to see the error)


# Creating a Custom Iterable Class for Countdown
class Countdown:
    def __init__(self, start):
        self.start = start  # Set the starting value

    def __iter__(self):
        return self  # Returning self as the iterator

    def __next__(self):
        if self.start <= 0:
            raise StopIteration  # Stop iteration when countdown reaches zero
        current = self.start
        self.start -= 1  # Decrement countdown value
        return current  # Return current countdown number

# Using the countdown iterator
print("\nCountdown Iterator Output:")
countdown = Countdown(5)
for num in countdown:
    print(num)  # Output: 5, 4, 3, 2, 1


# Manually Creating an Iterator
class MyIterator:
    def __init__(self):
        self.value = 1  # Start from 1

    def __iter__(self):
        return self  # Returns the iterator object itself

    def __next__(self):
        if self.value > 5:
            raise StopIteration  # Stop iteration when value exceeds 5
        result = self.value
        self.value += 1  # Increment value
        return result  # Return the current number

# Using the custom iterator
print("\nCustom Iterator Output:")
obj = MyIterator()
for num in obj:
    print(num)  # Output: 1, 2, 3, 4, 5

# Creating a new instance before converting to list (Avoid exhausted iterator issue)
obj = MyIterator()
print("\nCustom Iterator Output (Converting to List):")
print(list(obj))  # Output: [1, 2, 3, 4, 5]

# Creating a new instance before using next()
obj = MyIterator()
print("\nCustom Iterator Output using next():")
print(next(obj))  # Output: 1
print(next(obj))  # Output: 2
print(next(obj))  # Output: 3


# Corrected Count Class
class Count:
    def __init__(self, limit, current):
        self.limit = limit
        self.current = current

    def __iter__(self):
        return self

    def __next__(self):
        if self.current > self.limit:
            raise StopIteration
        num = self.current
        self.current += 1
        return num

print("\nCount Iterator Output:")
count = Count(3, 1)
for num in count:
    print(num)  # Output: 1, 2, 3
