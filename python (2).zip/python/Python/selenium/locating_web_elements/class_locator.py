from selenium import webdriver
from selenium.webdriver.common.by import By
import time

driver = webdriver.Chrome()

driver.get("file://C:/Users/Dell/Desktop/python/Python/selenium/locating_web_elements/login.html")

time.sleep(3)

# Locate elements using Class Name Locator
username = driver.find_element(By.CLASS_NAME, "username")
password = driver.find_element(By.CLASS_NAME, "password")
login_button = driver.find_element(By.CLASS_NAME, "login-button")

# Perform actions - wrong credentials
username.send_keys("test_user1")
password.send_keys("securePass1234")
login_button.click()
time.sleep(3)

username.clear()
password.clear()

# Perform actions - correct credentials
username.send_keys("test_user")
password.send_keys("securePass123")
login_button.click()

time.sleep(3)

driver.quit()
