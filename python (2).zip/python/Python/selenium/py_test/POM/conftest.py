import pytest
from selenium import webdriver

@pytest.fixture
def driver():
    driver = webdriver.Chrome()
    driver.maximize_window()
    yield driver  # Provide the driver instance to the test
    driver.quit()  # Cleanup after the test
