# Exercise 1: Reverse the tuple
tuple1 = (10, 20, 30, 40, 50)
tuple12 = tuple1[::-1]
print(tuple12)
# (50, 40, 30, 20, 10)

# Exercise 2: Access value 20 from the tuple
# The given tuple is a nested tuple. write a Python program to print the value 20.
tuple1 = ("Orange", [10, 20, 30], (5, 15, 25))
print(tuple1[1][1])
# 20

# Exercise 3: Create a tuple with single item 50

# Exercise 4: Unpack the tuple into 4 variables
# Write a program to unpack the following tuple into four variables and display each variable.
tuple1 = (10, 20, 30, 40)
a,b,c,d = tuple1
# # Your code
print(a) # should print 10
print(b) # should print 20
print(c) # should print 30
print(d) # should print 40

# Exercise 5: Swap two tuples in Python
tuple1 = (11, 22)
tuple2 = (99, 88)
# tuple1: (99, 88)
# tuple2: (11, 22)

# Exercise 6: Copy specific elements from one tuple to a new tuple
# Write a program to copy elements 44 and 55 from the following tuple into a new tuple.
tuple1 = (11, 22, 33, 44, 55, 66)
tuple2=()
for i in range(len(tuple1)):
    if(tuple1[i]==44 or tuple1[i] ==55):
        tuple2 = tuple2 + (tuple1[i],)  # Wrap the integer in a tuple
print(tuple2)
# tuple2: (44, 55)

# Exercise 7: Modify the tuple
# Given is a nested tuple. Write a program to modify the first item (22) of a list inside a following tuple to 222
tuple1 = (11, [22, 33], 44, 55)
for item in tuple1:
    if(type(item)==list):
        for i in range(len(item)):
            print(item[i])
            if(item[i]==22):
                item[i]=222

print(tuple1)


# tuple1: (11, [222, 33], 44, 55)

# Exercise 8: Sort a tuple of tuples by 2nd item
tuple1 = (('a', 23),('b', 37),('c', 11), ('d',29))


# (('c', 11), ('a', 23), ('d', 29), ('b', 37))

# Exercise 9: Counts the number of occurrences of item 50 from a tuple
tuple1 = (50, 10, 60, 70, 50)
count=0
for i in range(len(tuple1)):
    if tuple1[i]==50:
        count+=1
print(count)
# 2

# Exercise 10: Check if all items in the tuple are the same
def are_all_items_same(t):
    for i in range(len(t) - 1):
        if t[i] != t[i + 1]:
            return False
        
    return True

tuple1 = (45, 45, 453, 45,45,45)
print(are_all_items_same(tuple1))  # True
# True