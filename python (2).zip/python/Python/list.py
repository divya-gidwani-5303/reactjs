# Exercise 1: Reverse a list in Python
list1 = [100, 200, 400, 500]
# list1.sort(reverse=True)
list2=[]
i= len(list1)-1
while i>=0:
    list2.append(list1[i])
    i-=1
print(list2)
# Exercise 2: Concatenate two lists index-wise
list1 = ["M", "na", "i", "Ke"]
list2 = ["y", "me", "s", "lly"]
# ['My', 'name', 'is', 'Kelly']
list3=[]
for i in range(len(list2)):
    list3.append(list1[i]+list2[i])
print(list3)
# Exercise 3: Turn every item of a list into its square
numbers = [1, 2, 3, 4, 5, 6, 7]
# [1, 4, 9, 16, 25, 36, 49]
sq=[]
for num in numbers:
    sq.append(num*num)
print(sq)
# Exercise 4: Concatenate two lists in the following order
# ['Hello Dear', 'Hello Sir', 'take Dear', 'take Sir']
list1 = ["Hello ", "take "]
list2 = ["Dear", "Sir"]
list3=[]
for i in range(len(list1)):
    for j in range(len(list2)):
        list3.append(list1[i]+list2[j])
print(list3)
# Exercise 5: Iterate both lists simultaneously
list1 = [10, 20, 30, 40]
list2 = [100, 200, 300, 400]
# 10 400
# 20 300
# 30 200
# 40 100
for i in range(len(list1)):
        print(list1[i], list2[i])
# Exercise 6: Remove empty strings from the list of strings
list1 = ["Mike", "", "Emma", "Kelly", "", "Brad"]
list2=[]
# ["Mike", "Emma", "Kelly", "Brad"]
for i in range(len(list1)):
    if(list1[i]!=""):
        list2.append(list1[i])
print(list2)
     
# Exercise 7: Add new item to list after a specified item
list1 = [10, 20, [300, 400, [5000, 6000], 500], 30, 40]
#       [10, 20, [300, 400, [5000, 6000, 7000], 500], 30, 40]
for num in list1:
    if(type(num)==list):
        for num1 in num:
            if(type(num1)==list):
                for num2 in num1:
                    if num2==6000:
                        num1.append(7000)
print(list1)
               
list3 = [10, 20, [300, 400, [5000, 6000], 500], 30, 40]

# understand indexing
# list3[0] = 10
# list3[1] = 20
# list3[2] = [300, 400, [5000, 6000], 500]
# list3[2][2] = [5000, 6000]
# list3[2][2][1] = 6000

# solution
list3[2][2].append(7000)
print(list3)
          
# Exercise 8: Extend nested list by adding the sublist
list1 = ["a", "b", ["c", ["d", "e", ["f", "g"], "k"], "l"], "m", "n"]
#       ['a', 'b', ['c', ['d', 'e', ['f', 'g', 'h', 'i', 'j'], 'k'], 'l'], 'm', 'n']

# sub list to add
sub_list = ["h", "i", "j"]
list1[2][1][2].extend(sub_list)
print(list1)

# Exercise 9: Replace list’s item with new value if found
# You have given a Python list. Write a program to find value 20 in the list, and if it is present, replace it with 200. Only update the first occurrence of an item.
list1 = [5, 10, 15, 20, 25, 50, 20]
#       [5, 10, 15, 200, 25, 50, 20]
for i in range(len(list1)):
    if(list1[i]==20):
        list1[i]=200
        break
print(list1)

# Exercise 10: Remove all occurrences of a specific item from a list.
# Given a Python list, write a program to remove all occurrences of item 20.
list1 = [5, 20, 15, 20, 25, 50, 20]
x = 0
while x < len(list1):
    if list1[x] == 20:
        list1.pop(x)  
    else:
        x += 1  # Only increment when not removing to avoid skipping elements

print(list1)

listqa=[2,3,4,5,6]
print(listqa[::-1])

s="hello world"
v= s.split(" ")
print(v)
c=v[::-1]
print(" ".join(c))