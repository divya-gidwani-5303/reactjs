from bs4 import BeautifulSoup

html_doc = """<html><body><p class="intro">Intro paragraph</p><p>Another paragraph</p></body></html>"""
soup = BeautifulSoup(html_doc, "html.parser")

# Find first paragraph
print(soup.find("p").text)

# Find by class
print(soup.find("p", class_="intro").text)

# Find all paragraphs
for p in soup.find_all("p"):
    print(p.text)
