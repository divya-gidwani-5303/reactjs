from bs4 import BeautifulSoup

# Sample HTML document
html_doc = """
<html>
    <head>
        <title>Page Title</title>
    </head>
    <body>
        <h1>Main Heading</h1>
        <div class="container">
            <p class="intro">Introduction Paragraph</p>
            <p class="info">Additional Info</p>
            <a href="https://example.com">Click here</a>
        </div>

        <div class="content">
            <ul>
                <li>Item 1</li>
                <li>Item 2</li>
                <li>Item 3</li>
            </ul>
        </div>

        <footer>
            <p>Footer Content</p>
        </footer>
    </body>
</html>
"""

# Create a BeautifulSoup object
soup = BeautifulSoup(html_doc, "html.parser")

# Accessing Elements
print("\n🔹 Accessing Elements:")

# Accessing the first <p> tag
print("First <p> tag:", soup.p.text)

# Accessing the title
print("Title:", soup.title.text)

# Accessing an element with a class
info_paragraph = soup.find("p", class_="info")
print("Info Paragraph:", info_paragraph.text)

# Accessing an element by tag name
first_div = soup.find("div")
print("First <div> content:\n", first_div.prettify())

# Navigating the Parent of an Element
print("\n🔹 Navigating Parent Elements:")

# Get the parent of a <p> tag
print("Parent of <p>:", soup.p.parent.name)

# Get the parent of an <li> item
first_li = soup.find("li")
print("Parent of <li>:", first_li.parent.name)

# Navigating Children of an Element
print("\n🔹 Navigating Children of an Element:")

# Get all children of <div class="container">
container_div = soup.find("div", class_="container")
children = list(container_div.children)
print(f"Total children in .container: {len(children)}")

# Iterate over child elements
for child in container_div.children:
    if child.name:
        print(f"Child Tag: {child.name}, Content: {child.text.strip()}")

# Navigating Siblings
print("\n🔹 Navigating Sibling Elements:")

# Get next sibling of the first <p>
print("Next sibling of first <p>:", soup.p.next_sibling.text.strip())

# Get previous sibling of the second <p>
second_p = soup.find_all("p")[1]
print("Previous sibling of second <p>:", second_p.previous_sibling.text.strip())

# Get next sibling of the first <li>
first_li = soup.find("li")
print("Next sibling of first <li>:", first_li.next_sibling.text.strip())

# Finding Specific Elements
print("\n🔹 Searching for Specific Elements:")

# Find the footer paragraph
footer_p = soup.find("footer").p
print("Footer Paragraph:", footer_p.text)

# Find all <li> elements inside <ul>
list_items = soup.find("ul").find_all("li")
print(f"Total <li> items: {len(list_items)}")

# Print each <li> text
for li in list_items:
    print("List Item:", li.text)

# Using CSS Selectors
print("\n🔹 Using CSS Selectors:")

# Select element using a CSS class
intro_p = soup.select(".intro")[0]
print("CSS Select - Intro Paragraph:", intro_p.text)

# Select all list items
all_li = soup.select("ul li")
print(f"CSS Select - Total List Items: {len(all_li)}")

# Select using ID (If exists)
# print(soup.select("#some-id"))  # Example if an ID was present

# Extracting Attribute Values
print("\n🔹 Extracting Attributes:")

# Extract href from the <a> tag
link = soup.find("a")
print("Anchor href:", link["href"])

# Extract class name from <p>
p_class = soup.find("p", class_="info")["class"]
print("Paragraph class:", p_class)

# Counting Elements
print("\n🔹 Counting Elements:")

# Count all <p> tags
num_paragraphs = len(soup.find_all("p"))
print(f"Total Paragraphs: {num_paragraphs}")

# Count all <div> tags
num_divs = len(soup.find_all("div"))
print(f"Total Divs: {num_divs}")

# Count all <li> items
num_list_items = len(soup.find_all("li"))
print(f"Total List Items: {num_list_items}")

# Extracting All Links in the Page
print("\n🔹 Extracting All Links:")

all_links = soup.find_all("a")
for link in all_links:
    print(f"Link Text: {link.text}, URL: {link['href']}")

# Navigating Using .contents
print("\n🔹 Using .contents to Access Children:")

# Get children of the first <div>
first_div = soup.find("div")
div_children = first_div.contents
print(f"Total children inside first <div>: {len(div_children)}")

# Iterate and print child elements
for child in div_children:
    if child.name:
        print(f"Child: {child.name}, Content: {child.text.strip()}")

# Navigating Using .descendants (Iterate Over All Nested Elements)
print("\n🔹 Using .descendants to Iterate Over All Nested Elements:")

# Get all descendants inside body
body_descendants = list(soup.body.descendants)
print(f"Total descendants inside <body>: {len(body_descendants)}")

# Print first 10 descendants
for i, element in enumerate(body_descendants[:10], start=1):
    if element.name:
        print(f"{i}. {element.name}: {element.text.strip()}")

# Using .find_parent() and .find_parents()
print("\n🔹 Using .find_parent() and .find_parents():")

# Find the immediate parent of a paragraph
p_parent = soup.find("p").find_parent()
print("Immediate parent of <p>:", p_parent.name)

# Find all ancestor parents of the <p>
p_parents = soup.find("p").find_parents()
print("All parent elements of <p>:", [parent.name for parent in p_parents])

# Using .find_next() and .find_previous()
print("\n🔹 Using .find_next() and .find_previous():")

# Find the next element in the document
next_element = soup.p.find_next()
print("Next element after <p>:", next_element.name)

# Find the previous element in the document
previous_element = soup.find("li").find_previous()
print("Previous element before first <li>:", previous_element.name)
