# Closure Example
def outer_message_function(message):
    def inner_print_function():
        print(message)
    return inner_print_function

hello_function = outer_message_function("Hello!")
greetings_function = outer_message_function("Greetings!")

hello_function()  
greetings_function()  
# function remembers the inner function even after execution this prop is called closure

# Decorator Example 1
def simple_decorator(original_function):
    def wrapper_function():
        return original_function()
    return wrapper_function

def show_message():
    print('The show_message function was called')

decorated_show_message = simple_decorator(show_message)
decorated_show_message() 

# Decorator Example 2
def message_decorator(original_function):
    def wrapper_function():
        print(f'Wrapper executed before {original_function.__name__}')
        return original_function()
    return wrapper_function

@message_decorator
def print_message():
    print('The print_message function was called')

print_message()  

# Decorator Example 3 - Pretty Sum
def format_sum_decorator(sum_function):                                                                                     
    def formatted_sum(a, b):                                                                                         
        print(str(a) + " + " + str(b) + " is ", end="")                                                     
        return sum_function(a, b)                                                                                    
    return formatted_sum                                                                                            

@format_sum_decorator                                                                                               
def add_numbers(a, b):                                                                                             
    result = a + b                                                                                          
    print(result) 

add_numbers(5, 10)

