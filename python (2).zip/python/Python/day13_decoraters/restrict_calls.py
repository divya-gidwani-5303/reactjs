"""
Create a decorator @restrict_calls(max_calls) that:
Takes an argument max_calls (maximum times a function can be called).
Allows the function to execute only up to max_calls times.
After reaching the limit, prints "Function call limit reached!" and prevents further execution.
Apply this decorator to a function say_hello() that prints "Hello, Python!".
"""
def restrict_calls(max_calls):
    def decorator(func):
        def wrapper(*args, **kwargs):
            nonlocal max_calls
            if max_calls > 0:
                result = func(*args, **kwargs)
                max_calls -= 1
                return result
            else:
                print("Function call limit reached!")
        return wrapper
    return decorator

@restrict_calls(2)
def say_hello():
    print("Hello, Python")

say_hello()  
say_hello()  
say_hello()  
