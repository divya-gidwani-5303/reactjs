"""
Abstraction is the process of hiding the implementation details and showing only the essential features of an object.
In Python, we can achieve abstraction using abstract classes and methods.
"""

from abc import ABC, abstractmethod
# ABC is the abstract base class
class Vehicle(ABC):
    def __init__(self, brand, debug=False):
        self.brand = brand 
        self.debug = debug
        if self.debug:
            print(f"{brand} Vehicle created.") 

    @abstractmethod
    def start_engine(self):
        """Abstract method to start engine."""
        pass  
    
    @abstractmethod
    def stop_engine(self):
        """Abstract method to stop engine."""
        pass

class Car(Vehicle):
    def start_engine(self):
        if self.debug:
            print(f"{self.brand} Car engine started.") 
    
    def stop_engine(self):
        if self.debug:
            print(f"{self.brand} Car engine stopped.")

class Bike(Vehicle):
    def start_engine(self):
        if self.debug:
            print(f"{self.brand} Bike engine started.")
    
    def stop_engine(self):
        if self.debug:
            print(f"{self.brand} Bike engine stopped.")

# If you want to see debug messages while testing, you set debug=True.
# In production, you can disable them (debug=False) to keep the output clean.
car = Car("Toyota", debug=True)
car.start_engine()
car.stop_engine()

bike = Bike("Yamaha", debug=False)
bike.start_engine()
bike.stop_engine()

print(issubclass(Car, Vehicle))   # True
print(isinstance(car, Vehicle))   # True
print(isinstance(car, Car))       # True
print(isinstance(car, Bike))      # False
print(Vehicle.__abstractmethods__)  # {'start_engine', 'stop_engine'}


# payment system example 
class Payment(ABC):
    @abstractmethod
    def pay(self, amount):
        pass

class CreditCardPayment(Payment):
    def pay(self, amount):
        print(f"Paid {amount} Credit Card.")

class PayPalPayment(Payment):
    def pay(self, amount):
        print(f"Paid {amount} PayPal.")

payment1 = CreditCardPayment()
payment1.pay(100)

payment2 = PayPalPayment()
payment2.pay(200)


# Notification system example
class Notification(ABC):
    @abstractmethod
    def send(self, message):
        pass

class EmailNotification(Notification):
    def send(self, message):
        print(f"Sending email: {message}")

class SMSNotification(Notification):
    def send(self, message):
        print(f"Sending SMS: {message}")

def get_notification_method(method):
    if method == "email":
        return EmailNotification()
    elif method == "sms":
        return SMSNotification()
    else:
        raise ValueError("Invalid notification method.")

# Using the factory method
notifier = get_notification_method("email")
notifier.send("Hello, this is an email.")

notifier = get_notification_method("sms")
notifier.send("Hello, this is an SMS.")

# Shape class is an abstract class with an abstract method area. Circle and Rectangle are concrete classes that inherit from the Shape class and implement the area method.
class Shape(ABC):
    @abstractmethod
    def area(self):
        pass

class Circle(Shape):
    def __init__(self, radius):
        self.radius = radius

    def area(self):
        return 3.14 * self.radius * self.radius
    
class Rectangle(Shape): 
    def __init__(self, length, breadth):
        self.length = length
        self.breadth = breadth

    def area(self):
        return self.length * self.breadth
    
circle = Circle(5)
print(circle.area())

rectangle = Rectangle(4, 6)
print(rectangle.area())