# Create a Python program that simulates a Smart Home System using Abstraction, 
# Encapsulation, Inheritance, Method Overloading, Method Overriding, and Special Methods. 
# The system should manage multiple smart devices like Smart Lights, Smart Thermostats, and
# Smart Speakers.

class SmartDevice:
    def __init__(self, name, status):
        self.name = name
        self.status = status

    def __str__(self):
        return f"{self.name} is {self.status}"

    def turn_on(self):
        self.status = "On"

    def turn_off(self):
        self.status = "Off"

class SmartLight(SmartDevice):
    def __init__(self, name, status, color):
        super().__init__(name, status)
        self.color = color

    def __str__(self):
        return f"{self.name} is {self.status} and color is {self.color}"
    
    def change_color(self, color):
        self.color = color

class SmartThermostat(SmartDevice):
    def __init__(self, name, status, temperature):
        super().__init__(name, status)
        self.temperature = temperature

    def __str__(self):
        return f"{self.name} is {self.status} and temperature is {self.temperature}°C"
    
    def change_temperature(self, temperature):
        self.temperature = temperature

class SmartSpeaker(SmartDevice):
    def __init__(self, name, status, volume):
        super().__init__(name, status)
        self.volume = volume

    def __str__(self):
        return f"{self.name} is {self.status} and volume is {self.volume}"
    
    def change_volume(self, volume):
        self.volume = volume

light = SmartLight("Living Room Light", "Off", "White")
print(light)
light.turn_on()
light.change_color("Yellow")
print(light)

thermostat = SmartThermostat("Living Room Thermostat", "Off", 25)
print(thermostat)
thermostat.turn_on()
thermostat.change_temperature(22)
print(thermostat)

speaker = SmartSpeaker("Living Room Speaker", "Off", 50)
print(speaker)
speaker.turn_on()
speaker.change_volume(80)
print(speaker)

# Output:
# Living Room Light is Off and color is White
# Living Room Light is On and color is Yellow
# Living Room Thermostat is Off and temperature is 25°C