"""
print 
1  2  3  4  5 
2  4  6  8 10 
3  6  9 12 15 
4  8 12 16 20 
5 10 15 20 25 
"""

my_arr=[1,2,3,4,5]
x=0
while x<len(my_arr):
    print(my_arr[x],my_arr[x]*2,my_arr[x]*3,my_arr[x]*4,my_arr[x]*5)
    x+=1

for i in my_arr:
    print(i,i*2,i*3,i*4,i*5)

"""
Given an array of integers nums and an integer target, return indices of the two numbers such that they add up to target.
Input: nums = [2,7,11,15], target = 9
Output: [0,1]
"""
def finding_sum(list, sum_of_list):
    for i in range(len(list)):
        # print(list[i])
        for j in range(i + 1, len(list)):
            # print(list[j])
            if list[i] + list[j] == sum_of_list:
                # print(list[i],list[j], sum_of_list)  
                print([i,j]) 


i1=finding_sum([2, 7, 11, 15], 9)  # Output: [0, 1]
print(i1)

