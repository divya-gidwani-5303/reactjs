# Creating a dictionary with key-value pairs
my_dict = {
    "name": "John",
    "age": 25,
    "city": "New York"
}

# Printing the entire dictionary
print("\nOriginal Dictionary:", my_dict)

# Looping through Key-Value Pairs
print("\nLooping through Key-Value Pairs:")
for key, value in my_dict.items():
    print(f"{key}: {value}")
    print(key, ":", value)


# Accessing values using keys
print("\nAccessing Values:")
print("Name:", my_dict["name"])  # Output: John
print("Age:", my_dict["age"])    # Output: 25

# Using .get() method to safely access keys
print("\nUsing .get() method:")
print("Name (using get):", my_dict.get("name"))  # Output: John
print("Country (using get):", my_dict.get("country", "Not Found"))  
# Output: Not Found (since "country" key doesn't exist)

# Adding a new key-value pair to the dictionary
my_dict["email"] = "john@example.com"
print("\nAfter Adding Email:", my_dict)

# Updating an existing key-value pair
my_dict["age"] = 26
print("\nAfter Updating Age:", my_dict)

# Deleting a key using del
del my_dict["city"]
print("\nAfter Deleting 'city':", my_dict)

# Trying to delete 'city' again would cause an error, so we comment it out
# del my_dict["city"]  # Uncommenting this will cause an error because "city" is already deleted

# Using .pop() to remove a key and get its value
email = my_dict.pop("email")
print("\nPopped Email:", email)  # Output: john@example.com
print("After Popping Email:", my_dict)

# Attempting to remove a key that doesn't exist with a default value
phone = my_dict.pop("phone", "Not Available")  # If 'phone' doesn't exist, return "Not Available"
print("Phone:", phone)  # Output: Phone: Not Available

# Using len() to find the number of items in the dictionary
print("\nTotal Items in Dictionary:", len(my_dict))

# Checking if a key exists in the dictionary
print("\nChecking if 'name' exists:", "name" in my_dict)  # Output: True
print("Checking if 'email' exists:", "email" in my_dict)  # Output: False

# Looping through dictionary keys
print("\nLooping through Keys:")
for key in my_dict:
    print(key, "->", my_dict[key])


# Copying a dictionary
new_dict = my_dict.copy()
print("\nCopied Dictionary:", new_dict)

# Merging two dictionaries
extra_info = {"gender": "Male", "hobby": "Reading"}
my_dict.update(extra_info)
print("\nAfter Merging with another dictionary:", my_dict)

# Clearing the dictionary
my_dict.clear()
print("\nAfter Clearing Dictionary:", my_dict)

# Summary Output
print("\nFinal Dictionary (After Clearing):", my_dict)
