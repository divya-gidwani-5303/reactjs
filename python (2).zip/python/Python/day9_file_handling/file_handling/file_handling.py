import csv  # Import the csv module for handling CSV files

# ---- TEXT FILE HANDLING ----

# Writing to a text file (Mode: 'w' - Overwrites file if it exists, otherwise creates a new file)
with open("example.txt", "w") as txt_file:
    txt_file.write("Hello, World!\n")  # Writing a line to the file
    txt_file.write("Python file handling example.\n")  # Writing another line

# Reading from a text file (Mode: 'r' - Read-only, file must exist)
with open("example.txt", "r") as txt_file:
    text_content = txt_file.read()  # Reading the entire file content
    print("Text File Content:\n", text_content)  # Printing file content

# Appending to a text file (Mode: 'a' - Appends new content to the existing file)
with open("example.txt", "a") as txt_file:
    txt_file.write("This is an appended line.\n")  # Adds a new line at the end

# Reading the updated text file after appending
with open("example.txt", "r") as txt_file:
    print("Updated Text File Content:\n", txt_file.read())  # Printing the updated content

# ---- CSV FILE HANDLING ----

# Creating sample CSV data as a list of lists
csv_data = [
    ["Name", "Age", "City"],  # Column headers
    ["Alice", 30, "New York"],
    ["Bob", 25, "Los Angeles"]
]

# Writing to a CSV file (Mode: 'w' - Overwrites file if it exists, otherwise creates a new one)
with open("data.csv", "w", newline="") as csv_file:
    writer = csv.writer(csv_file)  # Create a CSV writer object
    writer.writerows(csv_data)  # Write multiple rows to the CSV file

# Reading from a CSV file (Mode: 'r' - Read-only, file must exist)
with open("data.csv", "r") as csv_file:
    reader = csv.reader(csv_file)  # Create a CSV reader object
    print("\n CSV File Content:")
    for row in reader:  # Loop through each row in the CSV file
        print(row)  # Print each row as a list

# Appending new rows to the CSV file (Mode: 'a' - Adds new rows without overwriting existing content)
new_data = [
    ["Charlie", 28, "Chicago"],
    ["David", 35, "Houston"]
]

with open("data.csv", "a", newline="") as csv_file:
    writer = csv.writer(csv_file)  # Create a CSV writer object
    writer.writerows(new_data)  # Append new rows to the file

# Reading the updated CSV file after appending new rows
with open("data.csv", "r") as csv_file:
    reader = csv.reader(csv_file)  # Create a CSV reader object
    print("\nUpdated CSV File Content:")
    for row in reader:  # Loop through each row
        print(row)  # Print the updated content
