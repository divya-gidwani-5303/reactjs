import csv
import os  # Import the csv module to handle CSV file operations

text_file = "example.txt"
csv_file = "data.csv"

try:
    # ---- TEXT FILE HANDLING ----

    # Writing to a text file ('w' mode - overwrites existing file)
    with open(text_file, "w") as txt_file:
        txt_file.write("Hello, Python!\n")  # Writing first line
        txt_file.write("This is a text file example.\n")  # Writing second line

    # Checking if the file exists before reading
    if os.path.exists(text_file):
        with open(text_file, "r") as txt_file:
            content = txt_file.read()  # Reading the entire file content
            if not content:
                raise ValueError("Error: The file is empty!")  # Raises an error if the file is empty
            print(" Text File Content:\n", content)  # Printing file content

    # Appending to a text file ('a' mode - adds new content at the end)
    with open(text_file, "a") as txt_file:
        txt_file.write("This is an appended line.\n")  # Appending a new line

    # Reading the updated text file after appending
    with open(text_file, "r") as txt_file:
        print(" Updated Text File Content:\n", txt_file.read())  # Printing the updated content

    # ---- CSV FILE HANDLING ----

    # Creating sample CSV data as a list of lists
    csv_data = [
        ["Name", "Age", "City"],  # Column headers
        ["Alice", 30, "New York"],
        ["Bob", 25, "Los Angeles"]
    ]

    # Writing to a CSV file ('w' mode - overwrites existing file)
    with open(csv_file, "w", newline="") as file:
        writer = csv.writer(file)  # Creating a CSV writer object
        writer.writerows(csv_data)  # Writing multiple rows at once

    # Reading from a CSV file ('r' mode - read-only)
    with open(csv_file, "r") as file:
        reader = csv.reader(file)  # Creating a CSV reader object
        print("\n CSV File Content:")
        for row in reader:  # Looping through each row
            print(row)  # Printing the row

    # Appending new rows to the CSV file ('a' mode - adds new rows without overwriting)
    new_data = [
        ["Charlie", 28, "Chicago"],
        ["David", 35, "Houston"]
    ]

    with open(csv_file, "a", newline="") as file:
        writer = csv.writer(file)  # Creating a CSV writer object
        writer.writerows(new_data)  # Appending new rows

    # Reading the updated CSV file after appending
    with open(csv_file, "r") as file:
        reader = csv.reader(file)  # Creating a CSV reader object
        print("\n Updated CSV File Content:")
        for row in reader:  # Looping through each row
            print(row)  # Printing the updated content

# ---- ERROR HANDLING ----
except FileNotFoundError:
    print("Error: The file was not found!")  # Handles missing file errors
except PermissionError:
    print("Error: Permission denied! You may not have the required access.")  # Handles permission issues
except IsADirectoryError:
    print("Error: Expected a file but found a directory!")  # Happens when opening a directory as a file
except NotADirectoryError:
    print("Error: A part of the path that should be a directory is actually a file!")  # Incorrect path structure
except EOFError:
    print("Error: Unexpected end of file encountered!")  # Occurs during input() or file reading
except UnicodeDecodeError:
    print("Error: File encoding issue! Try opening the file with the correct encoding.")  # Encoding mismatches
except OSError:
    print("Error: A system-related error occurred. This could be due to disk full, locked file, or OS-level issue.")  
except KeyboardInterrupt:
    print("\nProcess interrupted by user! Exiting safely...")  # Handles manual interruption (Ctrl+C)
except ValueError as e:
    print(f"Value Error: {e}")  # Handles custom errors (e.g., empty files, invalid data formats)
except Exception as e:
    print(f"An unexpected error occurred: {e}")  # Catches any other unknown errors
finally:
    print("\nFile handling complete!")  # Ensures this message always prints
